interface TMiningPower {
    power: number,
    pph: number,
    price: string,
    createdAt: string,
    updatedAt: string
};

export default TMiningPower;