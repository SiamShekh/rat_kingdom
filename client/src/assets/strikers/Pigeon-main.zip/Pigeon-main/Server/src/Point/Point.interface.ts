export interface TPoint {
    userId: string,
    point: number,
}