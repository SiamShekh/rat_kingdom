interface PointHouse {
    token: number,
    price: string,
    createdAt: string,
    updatedAt: string
};

export default PointHouse;