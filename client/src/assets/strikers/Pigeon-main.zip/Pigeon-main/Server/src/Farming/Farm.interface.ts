export interface TFarming {
    userId: string,
    farmingEndTime: string,
    claim: boolean
}