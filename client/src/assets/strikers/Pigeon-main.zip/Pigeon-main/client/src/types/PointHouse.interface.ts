interface PointHouse {
    _id: string
    token: number,
    price: string,
    createdAt: string,
    updatedAt: string
}

export default PointHouse;