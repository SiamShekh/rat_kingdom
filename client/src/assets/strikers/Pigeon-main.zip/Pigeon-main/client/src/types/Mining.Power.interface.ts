interface TMiningPower {
    _id: string
    power: number,
    pph: number,
    price: string,
    createdAt: string,
    updatedAt: string
}

export default TMiningPower;